import { rl } from '../utils/readline';
import { socket } from '../socket';

export function register() {
    rl.question('Enter Employee ID: ', employeeId => {
        rl.question('Enter Name: ', name => {
            rl.question('Enter Role: ', role => {
                socket.emit('register', { employeeId, name, role });
            });
        });
    });
}

export function login() {
    rl.question('Enter Employee ID: ', password => {
        rl.question('Enter Name: ', username => {
            socket.emit('authenticate', { password, username });
        });
    });
}
