// src/routes/chef.ts
import { Socket } from 'socket.io';
import { IFeedback } from '../../models/FeedBack';
import { pool } from '../../utils/db';
import { getTopFoodItems } from '../../Recomendation';

export const handleChefSocketEvents = (socket: Socket) => {
    socket.on('give_feedback', async (data: IFeedback) => {
        try {
            const connection = await pool.getConnection();
            await connection.execute(
                'INSERT INTO feedback (menuItemId, userId, feedbackText) VALUES (?, ?, ?)',
                [data.menuItemId, data.userId, data.feedbackText],
            );
            connection.release();
            socket.emit('give_feedback_response', {
                success: true,
                message: 'Feedback submitted successfully',
            });
        } catch (err) {
            socket.emit('give_feedback_response', {
                success: false,
                message: 'Database error',
            });
            console.error('Database query error', err);
        }
    });

    socket.on('get_recommendation', async data => {
        try {
            const top5FoodItems = await getTopFoodItems(data.menuType);
            console.log('Top 5 Food Items:', top5FoodItems);
        } catch (error) {
            console.error('Error fetching top 5 food items:', error);
        }
    });
};
