import { Socket } from 'socket.io';
import { pool } from '../../utils/db';
import { RowDataPacket } from 'mysql2/promise';

export const handleEmployeeSocketEvents = (socket: Socket) => {
    socket.on('vote_for_menu', async data => {
        const { userId } = data;

        try {
            const connection = await pool.getConnection();
            await connection.beginTransaction();

            const [userVotes] = await connection.execute<RowDataPacket[]>(
                'SELECT userId FROM rollover',
            );

            let userHasVoted = false;

            userVotes.forEach(row => {
                if (row && Array.isArray(row.userId)) {
                    votedUsers = row.userId;
                } else {
                    console.error(
                        'Row does not contain valid userId array:',
                        row,
                    );
                    return;
                }

                if (votedUsers.length === 0) {
                    console.log('No users have voted in this entry.');
                    return;
                }

                if (votedUsers.includes(userId)) {
                    userHasVoted = true;
                }
            });

            if (userHasVoted) {
                socket.emit('vote_for_menu_response', {
                    success: false,
                    message: 'You have already voted for an item.',
                });
                await connection.rollback();
                connection.release();
                return;
            }

            const [results] = await connection.execute<RowDataPacket[]>(
                'SELECT usersId FROM rollover WHERE id = ? FOR UPDATE',
                [data.rolloverId],
            );

            if (results.length === 0) {
                socket.emit('vote_for_menu_response', {
                    success: false,
                    message: 'Rollover item not found.',
                });
                await connection.rollback();
                connection.release();
                return;
            }

            let votedUsers = [];

            if (typeof results[0].usersId === 'string') {
                try {
                    votedUsers = JSON.parse(results[0].usersId);
                } catch (error) {
                    console.error('Failed to parse results[0].usersId:', error);
                    await connection.rollback();
                    connection.release();
                    return;
                }
            } else if (Array.isArray(results[0].usersId)) {
                votedUsers = results[0].usersId;
            } else {
                console.error(
                    'Row does not contain valid usersId array:',
                    results[0],
                );
                await connection.rollback();
                connection.release();
                return;
            }

            votedUsers.push(userId);

            await connection.execute(
                'UPDATE rollover SET usersId = ?, count = count + 1 WHERE id = ?',
                [JSON.stringify(votedUsers), data.rolloverId],
            );

            await connection.commit();
            connection.release();

            socket.emit('vote_for_menu_response', {
                success: true,
                message: 'Your vote has been recorded successfully.',
            });
        } catch (err) {
            socket.emit('vote_for_menu_response', {
                success: false,
                message: 'Database error occurred.',
            });
            console.error('Database query error', err);
        }
    });

    socket.on('view_menu', async () => {
        try {
            const connection = await pool.getConnection();
            const [results] = await connection.execute(
                'SELECT * FROM menuitem',
            );
            connection.release();

            socket.emit('view_menu_response', { success: true, menu: results });
        } catch (err) {
            socket.emit('view_menu_response', {
                success: false,
                message: 'Database error',
            });
            console.error('Database query error', err);
        }
    });

    socket.on('check_item_exists', async ({ id }) => {
        try {
            const connection = await pool.getConnection();
            const [results]: any = await connection.execute(
                'SELECT COUNT(*) as count FROM menuitem WHERE id = ?',
                [id],
            );
            connection.release();

            const exists = results[0].count > 0;
            socket.emit('check_item_exists_response', {
                success: true,
                exists,
            });
        } catch (err) {
            socket.emit('check_item_exists_response', {
                success: false,
                message: 'Database error',
            });
            console.error('Database query error', err);
        }
    });

    socket.on(
        'give_feedBack',
        async ({ id, name, price, feedbackText, userId }) => {
            try {
                const connection = await pool.getConnection();

                await connection.execute(
                    'UPDATE menuitem SET name = ?, price = ? WHERE id = ?',
                    [name, price, id],
                );

                await connection.execute(
                    'INSERT INTO feedback (menuitem_id, user_id, feedback_text) VALUES (?, ?, ?)',
                    [id, userId, feedbackText],
                );

                connection.release();

                socket.emit('update_item_response', { success: true });
            } catch (err) {
                socket.emit('update_item_response', {
                    success: false,
                    message: 'Database error',
                });
                console.error('Database query error', err);
            }
        },
    );

    socket.on('view_feedbacks', async data => {
        const { userId } = data;
        try {
            const connection = await pool.getConnection();
            const [results] = await connection.execute(
                'SELECT * FROM Feedback',
            );
            connection.release();

            socket.emit('view_feedbacks_response', {
                success: true,
                menu: results,
                useId: userId,
            });
        } catch (err) {
            socket.emit('view_feedbacks_response', {
                success: false,
                message: 'Database error',
            });
            console.error('Database query error', err);
        }
    });
};
