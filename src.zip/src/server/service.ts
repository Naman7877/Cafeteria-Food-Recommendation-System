// src/server.ts
import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import { handleAdminSocketEvents } from './routers/admin';
import { handleEmployeeSocketEvents } from './routers/employee';
import { handleChefSocketEvents } from './routers/chef';
import { handleAuthSocketEvents } from './routers/aunthectaion';

const app = express();
const server = http.createServer(app);
const io = new Server(server);

io.on('connection', socket => {
    handleAuthSocketEvents(socket);
    handleAdminSocketEvents(socket);
    handleEmployeeSocketEvents(socket);
    handleChefSocketEvents(socket);
});

server.listen(3000, () => {
    console.log('Cafeteria application : ');
});
