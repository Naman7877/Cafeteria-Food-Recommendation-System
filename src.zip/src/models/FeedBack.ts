export interface IFeedback {
    id: number;
    menuItemId: number;
    userId: number;
    feedbackText: string;
    created_at: Date;
}
